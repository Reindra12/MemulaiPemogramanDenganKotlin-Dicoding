// main function
fun main() {

    val value1 = 10
    val value2 = 10

    sum(value1, value2)
}

fun sum(value1: Int, value2: Int) = value1 + value2