// main function
fun main() {
    println("Hello Kotlin!")
}