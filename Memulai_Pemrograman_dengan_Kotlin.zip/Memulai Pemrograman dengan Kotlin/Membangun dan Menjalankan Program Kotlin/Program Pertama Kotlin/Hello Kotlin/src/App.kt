fun main() {
    print("Hello Kotlin!")
}